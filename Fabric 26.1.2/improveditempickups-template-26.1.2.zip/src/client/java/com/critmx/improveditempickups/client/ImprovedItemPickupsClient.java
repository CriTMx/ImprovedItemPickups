package com.critmx.improveditempickups.client;

import net.fabricmc.api.ClientModInitializer;

public class ImprovedItemPickupsClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}